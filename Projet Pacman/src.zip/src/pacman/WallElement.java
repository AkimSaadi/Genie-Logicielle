package pacman;


import core.SceneElement;
import physics.PhysicalElement;

public class WallElement extends SceneElement {

    public WallElement() {
        super();
    }

    public WallElement(PhysicalElement physical) {
        super(physical);
    }


}
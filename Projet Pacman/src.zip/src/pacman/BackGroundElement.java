package pacman;

import core.SceneElement;

public class BackGroundElement extends SceneElement {
}

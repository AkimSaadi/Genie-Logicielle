package pacman;

import core.SceneElement;

public class UIElement extends SceneElement {


}

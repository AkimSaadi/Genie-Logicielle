package physics;

import java.util.ArrayList;

public class PhysicsMotor {

    public ArrayList<PhysicalElement> physicalElementsList = new ArrayList<>();

    public ArrayList<PhysicalElement> collisionFlags       = new ArrayList<>();


}
